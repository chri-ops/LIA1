﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ExampleWebApp.Models;
using ExampleWebApp.Database;

namespace ExampleWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private MaintenanceDataService DataService;

        public HomeController(ILogger<HomeController> logger, MaintenanceDataService service)
        {
            DataService = service;

            _logger = logger;
        }

        public IActionResult Index()
        {
            HomeViewModel model = new HomeViewModel();

            // Hämta alla pågående åtgärder
            model.OngoingActions = DataService.GetOngoingActions();

            // Hämta alla kommande åtgärder (som borde startas)
            List<OperationMachine> allOperationMachines = DataService.GetAllOperationMachines();

            // Hämta alla underhåll och spara endast dem utan någon kopplad maskin i ViewItems
            List<Operation> allOperations = DataService.GetAllOperations();
            //List<Operation> operationsWithoutMachine = new List<Operation>();

            foreach (Operation operation in allOperations)
            {
                // Plocka endast ut de underhåll som inte är kopplade till någon maskin (inte finns i kopplingstabellen)
                if (!allOperationMachines.Any(om => om.OperationId == operation.Id))
                {
                    // Plocka endast ut de underhåll som inte redan är påbörjade
                    if (!model.OngoingActions.Any(action => action.OperationId == operation.Id))
                    {
                        Database.Action latestCompleted = DataService.GetLatestCompletedAction(operation.Id, null);
                        if (operation.Start <= DateTime.Now &&
                            (latestCompleted == null || operation.Next(latestCompleted) <= DateTime.Now))
                        {
                            HomeViewItem viewItem = new HomeViewItem();

                            viewItem.OperationMachine.MachineId = null;
                            viewItem.OperationMachine.OperationId = operation.Id;
                            viewItem.OperationStart = operation.Start;
                            viewItem.OperationScheduleType = operation.ScheduleType;
                            viewItem.OperationInterval = operation.Interval;
                            viewItem.OperationActive = operation.Active;
                            viewItem.Scheduled = operation.Next(latestCompleted);

                            //operationsWithoutMachine.Add(operation);
                            model.ScheduledActions.Add(viewItem);
                        }
                    }
                }
            }

            foreach (OperationMachine om in allOperationMachines)
            {
                // Välj endast ut de utföranden som inte är påbörjade (som finns med i OngoingActions)
                if (!model.OngoingActions.Any(action => action.OperationId == om.OperationId && action.MachineId == om.MachineId))
                {
                    Operation operation = DataService.GetOperationById(om.OperationId);
                    Database.Action latestCompleted = DataService.GetLatestCompletedAction(om.OperationId, om.MachineId);
                    if (operation.Start <= DateTime.Now &&
                        (latestCompleted == null || operation.Next(latestCompleted) <= DateTime.Now))
                    {
                        HomeViewItem viewItem = new HomeViewItem();

                        viewItem.OperationMachine.MachineId = om.MachineId;
                        viewItem.OperationMachine.OperationId = om.OperationId;
                        viewItem.OperationStart = operation.Start;
                        viewItem.OperationScheduleType = operation.ScheduleType;
                        viewItem.OperationInterval = operation.Interval;
                        viewItem.OperationActive = operation.Active;
                        viewItem.Scheduled = operation.Next(latestCompleted);

                        model.ScheduledActions.Add(viewItem);
                    }
                }
            }

            model.ScheduledActions = model.ScheduledActions.OrderBy(x => x.Scheduled).ToList();

            return View(model);
        }

        //private List<OperationMachine> GetOperationMachines(List<Database.Action> uncompletedActions)
        //{
        //    List<OperationMachine> operationMachines = new List<OperationMachine>();

        //    foreach (Database.Action action in uncompletedActions)
        //    {
        //        OperationMachine operationMachine = new OperationMachine();
        //        operationMachine.OperationId = action.OperationId;
        //        operationMachine.MachineId = action.MachineId;
        //        operationMachines.Add(operationMachine);
        //    }

        //    return operationMachines;
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
