﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ExampleWebApp.Database;
using ExampleWebApp.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Action = ExampleWebApp.Database.Action;
using Task = ExampleWebApp.Database.Task;

namespace ExampleWebApp.Controllers
{
    public class ActionController : Controller
    {
        private MaintenanceDataService DataService;
        private readonly IWebHostEnvironment hostingEnvironment;

        public ActionController(MaintenanceDataService service, IWebHostEnvironment environment)
        {
            DataService = service;
            hostingEnvironment = environment;
        }

        // GET: Action
        public ActionResult Index()
        {
            return View();
        }


        // GET: Action/Execute
        public IActionResult Execute(int operationId, int? machineId, long actionId, [FromQuery] bool actionExists,
            int returnToOperationId)
        {
            ActionExecuteViewModel model = new ActionExecuteViewModel();

            if (actionExists == false) // Använder operationId och machineId
                                       // Samt använder model.Tasks som lista för underhållets befintliga Tasks (vid start)
            {
                model.ActionExists = false;
                model.Tasks = DataService.GetTasks(operationId).OrderBy(t => t.TaskOrder).ToList();
                model.Action.OperationId = operationId;
                model.Action.MachineId = machineId;
                model.Action.Name = DataService.GetOperationById(operationId).Name;
                if (machineId != null && machineId != 0)
                {
                    model.Action.MachineName = DataService.GetMachineById(machineId).Name;
                }
                else
                {
                    model.Action.MachineName = null;
                }
            }

            if (actionExists == true) // Använder actionId
                                      // Samt använder model.ActionTasks som lista för utförandets undansparade ActionTasks
            {
                model.ActionExists = true;
                model.Action = DataService.GetAction(actionId);
                
                // Hämta aktiviteter som kopierats vid start av utförande
                // (instruktioner vid start gäller, även om ändringar skett i dessa efter)
                //
                model.ActionTasks = DataService.GetActionTasks(model.Action.Id);
                //foreach (ActionTask actionTask in actionTasks)
                //{
                //    Database.Task viewTask = new Database.Task();
                //    viewTask.HasResult = actionTask.HasResult;
                //    viewTask.Instruction = actionTask.Instruction;
                //    viewTask.Name = actionTask.Name;
                //    viewTask.TaskOrder = actionTask.TaskOrder;

                //    // Id behövs hittills för att hämta Filer!
                //    viewTask.Id = actionTask.TaskId;

                //    model.Tasks.Add(viewTask);
                //}
            }

            // Fyll lista för inputfält för resultat
            //foreach (Database.Task task in model.Tasks)
            foreach (ActionTask actionTask in model.ActionTasks)
            {
                model.HasResultList.Add(actionTask.HasResult);
                model.ResultList.Add("");
            }

            ViewData["ContentRootPath"] = hostingEnvironment.ContentRootPath;
            ViewData["returnToOperationId"] = returnToOperationId;

            // Hämta filer för alla Tasks
            //List<List<TaskFile>> listOfTaskFileLists = new List<List<TaskFile>>();

            //for (int i = 0; i < model.Tasks.Count; i++)
            //{
            //    List<TaskFile> taskFiles = DataService.GetTaskFiles(model.Tasks[i].Id);
            //    listOfTaskFileLists.Add(taskFiles);
            //}

            //model.ListOfTaskFileLists = listOfTaskFileLists;
            
            return View(model);
        }

        // POST: Action/Execute
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Execute(ActionExecuteViewModel model, string actionState, int returnToOperationId)
        {
            if (actionState == "Start")
            {
                DateTime d = DateTime.Now;

                // This is a fix not to store/display more than second precision of DateTime property.
                model.Action.Started = new DateTime(d.Year, d.Month, d.Day, d.Hour, d.Minute, d.Second, 0);
                
                // Following line is only needed as long as validation is not fixed for the view...
                // Currently the user has to fill in CompletedBy even when starting....
                // TODO: Fix the validation for the view..
                model.Action.CompletedBy = null;
                model.Action.Name = DataService.GetOperationById(model.Action.OperationId).Name;
                if (model.Action.MachineId != 0 && model.Action.MachineId != null)
                {
                    model.Action.MachineName = DataService.GetMachineById(model.Action.MachineId).Name;
                }
                else
                {
                    model.Action.MachineName = null;
                }

                DataService.AddAction(model.Action);

                // Kopiera aktiviteter som de är vid start från Tasks till ActionTasks för denna Action.
                // Lägg till: avtryck av bifogade filer
                model.Tasks = DataService.GetTasks(model.Action.OperationId).OrderBy(t => t.TaskOrder).ToList();

                List<ActionTask> actionTasks = new List<ActionTask>();

                // Loopa igenom Tasks för detta utförande/underhåll..
                // och kopiera Task-properties till ActionTasks
                for (int i = 0; i < model.Tasks.Count; i++)
                {
                    ActionTask actionTask = new ActionTask();
                    Task currentTask = model.Tasks[i];

                    actionTask.ActionId = model.Action.Id;
                    actionTask.TaskId = currentTask.Id;
                    actionTask.TaskOrder = currentTask.TaskOrder;
                    actionTask.Name = currentTask.Name;
                    actionTask.Instruction = currentTask.Instruction;
                    actionTask.HasResult = currentTask.HasResult;
                    //actionTask.Result = model.ResultList[i];

                    //// Kan vi för varje actionTask i loopen hämta dess filer med TaskId?
                    //List<TaskFile> taskFiles = DataService.GetTaskFiles(actionTask.TaskId);

                    actionTasks.Add(actionTask);
                }

                // Spara ActionTasks som de är vid start av underhåll, i databasen.
                // Få tillbaks listan av ActionTasks igen, men med nya Id:n från databasen.
                List<ActionTask> savedActionTasks = DataService.AddActionTasks(actionTasks); // med tilldelade Id-nummer

                for (int i = 0; i < savedActionTasks.Count; i++)
                {
                    // För varje lagrad ny ActionTask
                    // Hämta motsvarande Task för ActionTask
                    List<ActionTaskFile> actionTaskFiles = new List<ActionTaskFile>();
                    ActionTask currentActionTask = savedActionTasks[i];
                    Task correspondingTask = DataService.GetTaskById(currentActionTask.TaskId);

                    // Hämta bifogade filer för motsvarande Task
                    List<TaskFile> taskFiles = DataService.GetTaskFiles(correspondingTask.Id);
                    foreach (TaskFile taskFile in taskFiles)
                    {
                        ActionTaskFile newActionTaskFile = new ActionTaskFile();
                        newActionTaskFile.ActionTaskId = currentActionTask.Id;
                        newActionTaskFile.FileId = taskFile.FileId;
                        actionTaskFiles.Add(newActionTaskFile);
                    }

                    DataService.AddActionTaskFiles(actionTaskFiles);
                }
            }

            // !!! Det här blocket används inte längre, då vi delat upp i Starta och Slutför..
            // *
            //else if (actionState == "StartAndComplete")
            //{
            //    DateTime d = DateTime.Now;

            //    // This is a fix not to store/display more than second precision of DateTime property.
            //    model.Action.Started = new DateTime(d.Year, d.Month, d.Day, d.Hour, d.Minute, d.Second, 0);
            //    model.Action.Completed = model.Action.Started;

            //    DataService.AddAction(model.Action);

            //    // Copy Tasks of Action into ActionTask objects for archivation of completed actions/tasks:
            //    model.Tasks = DataService.GetTasks(model.Action.OperationId).OrderBy(t => t.TaskOrder).ToList();
            //    List<ActionTask> actionTasks = new List<ActionTask>();
            //    for (int i = 0; i < model.Tasks.Count; i++)
            //    {
            //        ActionTask actionTask = new ActionTask();
            //        actionTask.ActionId = model.Action.Id;
            //        actionTask.TaskId = model.Tasks[i].Id;
            //        actionTask.TaskOrder = model.Tasks[i].TaskOrder;
            //        actionTask.Name = model.Tasks[i].Name;
            //        actionTask.Instruction = model.Tasks[i].Instruction;
            //        actionTask.HasResult = model.Tasks[i].HasResult;
            //        actionTask.Result = model.ResultList[i];

            //        actionTasks.Add(actionTask);
            //    }

            //    DataService.AddActionTasks(actionTasks);
            //}

            else if (actionState == "Complete")
            {
                DateTime d = DateTime.Now;

                // This is a fix not to store/display more than second precision of DateTime property.
                model.Action.Completed = new DateTime(d.Year, d.Month, d.Day, d.Hour, d.Minute, d.Second, 0);

                DataService.UpdateAction(model.Action);

                // ActionTask update...
                List<ActionTask> actionTasks = DataService.GetActionTasks(model.Action.Id);

                for (int i = 0; i < actionTasks.Count; i++)
                {
                    actionTasks[i].Result = model.ResultList[i];
                }

                DataService.UpdateActionTasks(actionTasks);

                //// Copy Tasks of Action into ActionTask objects for archivation of completed actions/tasks:
                //model.Tasks = DataService.GetTasks(model.Action.OperationId).OrderBy(t => t.TaskOrder).ToList();
                //List<ActionTask> actionTasks = new List<ActionTask>();
                //for (int i = 0; i < model.Tasks.Count; i++)
                //{
                //    ActionTask actionTask = new ActionTask();
                //    actionTask.ActionId = model.Action.Id;
                //    actionTask.TaskId = model.Tasks[i].Id;
                //    actionTask.TaskOrder = model.Tasks[i].TaskOrder;
                //    actionTask.Name = model.Tasks[i].Name;
                //    actionTask.Instruction = model.Tasks[i].Instruction;
                //    actionTask.HasResult = model.Tasks[i].HasResult;
                //    actionTask.Result = model.ResultList[i];

                //    actionTasks.Add(actionTask);
                //}

                //DataService.AddActionTasks(actionTasks);

                // DataService.UpdateActionTasks(actionTasks);
            }

            if (actionState == "Start")
            {
                Action action = DataService.GetAction(model.Action.OperationId, model.Action.MachineId);
                return RedirectToAction("Execute", "Action", new { actionId = action.Id, actionExists = true });
            }

            if (returnToOperationId != 0)
            {
                return RedirectToAction("ActionsByOperation", "Action", new { operationId = returnToOperationId });
            }

            return RedirectToAction("Index", "Home");
        }

        // GET: Action/Create
        public ActionResult Add(int operationId, int machineId)
        {
            Operation operation = DataService.GetOperationById(operationId);
            ActionAddViewModel model = new ActionAddViewModel();
            model.OperationId = operationId;
            model.MachineId = machineId;
            model.OperationActive = operation.Active;
            model.OperationInterval = operation.Interval;
            model.OperationName = operation.Name;
            model.OperationScheduleType = operation.ScheduleType;
            model.OperationStart = operation.Start;

            ViewData["OperationName"] = DataService.GetOperationById(operationId).Name;
            ViewData["MachineName"] = DataService.GetMachineById(machineId).Name;
            ViewData["ContentRootPath"] = hostingEnvironment.ContentRootPath;

            model.Tasks = DataService.GetTasks(operationId).OrderBy(t => t.TaskOrder).ToList();

            return View(model);
        }

        // POST: Action/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Add(ActionAddViewModel model)
        {
            try
            {
                // TODO: Add insert logic here

                Action action = new Database.Action();
                DateTime d = DateTime.Now;
                action.Started = new DateTime(d.Year, d.Month, d.Day, d.Hour, d.Minute, d.Second, 0); // This is a fix not to store/display more than second precision of DateTime property.
                action.StartedBy = model.StartedBy;
                action.Comment = model.Comment;
                action.OperationId = model.OperationId;
                action.MachineId = model.MachineId;
                action.Comment = model.Comment;

                DataService.AddAction(action);

                return RedirectToAction("Index", "Home");
            }
            catch
            {
                return View();
            }
        }

        // GET: Action/Edit/5
        public ActionResult Edit(long id)
        {
            Action action = DataService.GetAction(id);

            ActionEditViewModel model = new ActionEditViewModel();

            Operation operation = DataService.GetOperationById(action.OperationId);

            // ViewModel-props
            model.Id = action.Id;
            model.OperationId = action.OperationId;
            model.MachineId = action.MachineId;
            model.Started = action.Started;
            model.StartedBy = action.StartedBy;
            model.Completed = action.Completed;
            model.CompletedBy = action.CompletedBy;
            model.Comment = action.Comment;

            // ViewModel.Operation-props
            model.OperationActive = operation.Active;
            model.OperationInterval = operation.Interval;
            model.OperationName = operation.Name;
            model.OperationScheduleType = operation.ScheduleType;
            model.OperationStart = operation.Start;

            //ViewModel.Task-props (list)
            model.Tasks = DataService.GetTasks(action.OperationId).OrderBy(t => t.TaskOrder).ToList();

            foreach (Database.Task task in model.Tasks)
            {
                model.HasResultList.Add(task.HasResult);
                model.ResultList.Add("");
            }

            ViewData["OperationName"] = DataService.GetOperationById(action.OperationId).Name;
            ViewData["MachineName"] = DataService.GetMachineById(action.MachineId).Name;
            ViewData["ContentRootPath"] = hostingEnvironment.ContentRootPath;

            return View(model);
        }

        // POST: Action/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(ActionEditViewModel model)
        {
            model.Completed = DateTime.Now;

            // Pick up model-props and put them in action-props.
            Action action = DataService.GetAction(model.Id);
            action.Comment = model.Comment;
            action.Completed = model.Completed;
            action.CompletedBy = model.CompletedBy;
            action.MachineId = model.MachineId;
            action.OperationId = model.OperationId;
            action.Started = model.Started;
            action.StartedBy = model.StartedBy;

            // Copy Tasks of Action into ActionTask objects for archivation of completed actions/tasks:
            model.Tasks = DataService.GetTasks(action.OperationId).OrderBy(t => t.TaskOrder).ToList();
            List<ActionTask> actionTasks = new List<ActionTask>();
            for (int i = 0; i < model.Tasks.Count; i++)
            {
                ActionTask actionTask = new ActionTask();
                actionTask.ActionId = action.Id;
                actionTask.TaskId = model.Tasks[i].Id;
                actionTask.TaskOrder = model.Tasks[i].TaskOrder;
                actionTask.Name = model.Tasks[i].Name;
                actionTask.Instruction = model.Tasks[i].Instruction;
                actionTask.HasResult = model.Tasks[i].HasResult;
                actionTask.Result = model.ResultList[i];

                actionTasks.Add(actionTask);
            }

            DataService.AddActionTasks(actionTasks);
            DataService.UpdateAction(action);

            return RedirectToAction("Index", "Home");
        }

        // GET: Action/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Action/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public IActionResult ActionsByOperation(int operationId)
        {
            List<Action> actions = DataService.GetActionsForOperation(operationId).OrderByDescending(action => action.Completed).ToList();

            ViewData["OperationName"] = DataService.GetOperationById(operationId).Name;

            ViewData["MachineList"] = DataService.GetMachinesIdByOperationId(operationId);

            foreach (Action action in actions)
            {
                if (action.Completed == null)
                {
                    ViewData["AnyOngoing"] = "true";
                }

                if (action.Completed != null)
                {
                    ViewData["AnyCompleted"] = "true";
                }
            }

            return View(actions);
        }

        public IActionResult Details(long actionId)
        {
            ActionDetailsModel model = new ActionDetailsModel();
            Action action = DataService.GetAction(actionId);

            model.Id = action.Id;
            model.Comment = action.Comment;
            model.Completed = action.Completed;
            model.CompletedBy = action.CompletedBy;
            model.MachineId = action.MachineId;
            model.MachineName = action.MachineName;
            model.Name = action.Name;
            model.OperationId = action.OperationId;
            model.Started = action.Started;
            model.StartedBy = action.StartedBy;

            List<ActionTask> actionTasks = DataService.GetActionTasks(actionId);
            model.ActionTasks = actionTasks;
            
            ViewData["ContentRootPath"] = hostingEnvironment.ContentRootPath;

            return View(model);
        }
    }
}