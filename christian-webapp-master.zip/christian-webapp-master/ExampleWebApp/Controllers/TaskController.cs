﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ExampleWebApp.Database;
using ExampleWebApp.Models;
using ExampleWebApp.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using File = ExampleWebApp.Database.File;
using Task = ExampleWebApp.Database.Task;

namespace ExampleWebApp.Controllers
{
    public class TaskController : Controller
    {
        MaintenanceDataService DataService;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly InformationService Info;

        public TaskController(MaintenanceDataService service, IWebHostEnvironment environment, InformationService info)
        {
            DataService = service;
            hostingEnvironment = environment;
            Info = info;
        }
        public IActionResult Index(int operationId)
        {
            return View();
        }

        //[HttpGet]
        //[ValidateAntiForgeryToken]
        public IActionResult Add(int operationId)
        {
            Task task = new Task();

            task.OperationId = operationId;

            Operation operation = DataService.GetOperationById(operationId);

            List<Task> tasksOfOperation = DataService.GetTasks(operationId);

            ViewData["tasksOfOperation"] = tasksOfOperation;

            ViewData["numberOfTasks"] = tasksOfOperation.Count;

            ViewData["operationName"] = operation.Name;

            return View(task);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(Task task)
        {
            task.CreatedDate = DateTime.Now;
            task.CreatedBy = "Christian"; // User.Identity.Name;
            
            DataService.AddTask(task);

            return RedirectToAction("Edit", "Operation", new { id = task.OperationId });
        }

        public IActionResult Edit(int id)
        {
            TaskViewModel model = new TaskViewModel();
            model.Task = DataService.GetTaskById(id);

            Operation operation = DataService.GetOperationById(model.Task.OperationId);
            List<Task> tasksOfOperation = DataService.GetTasks(model.Task.OperationId);

            ViewData["operationName"] = operation.Name;
            ViewData["tasksOfOperation"] = tasksOfOperation;
            ViewData["numberOfTasks"] = tasksOfOperation.Count;

            // OLD Logic for getting the files added by user for this Task:

            //string path = Path.Combine(hostingEnvironment.ContentRootPath, "WorkFiles", model.Task.Id.ToString());
            //if (Directory.Exists(path))
            //{
            //    string[] fileNames = Directory.GetFileSystemEntries(@path);
            //    for (int i = 0; i < fileNames.Length; i++)
            //    {
            //        fileNames[i] = Path.GetFileName(fileNames[i]); // Corrects by removing path from file; leaving only filename.
            //    }

            //    ViewData["fileNames"] = fileNames;
            //}
            //else
            //{
            //    ViewData["fileNames"] = new string[0];
            //}

            // NEW Logic for getting the files added by user for this Task:
            List<TaskFile> taskfiles = DataService.GetTaskFiles(model.Task.Id);

            model.TaskFiles = taskfiles;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(TaskViewModel updateModel)
        {
            updateModel.Task.Id = updateModel.Id; // Plocka upp Id från vymodellen.

            if (ModelState.IsValid)
            {
                if (updateModel.Files.Count > 0)
                {
                    foreach (IFormFile file in updateModel.Files)
                    {
                        string fileName = Path.GetFileName(file.FileName);

                        // Lägg till fil i Files-tabell
                        File newFile = new File();
                        newFile.Name = fileName;
                        int fileId = DataService.AddFile(newFile);

                        // Lägg till koppling Task och File i TaskFiles-tabell
                        TaskFile taskFile = new TaskFile();
                        taskFile.FileId = fileId;
                        taskFile.TaskId = updateModel.Task.Id;
                        DataService.AddTaskFile(taskFile);

                        // Spara fil till disk
                        string path = Path.Combine(hostingEnvironment.ContentRootPath, "WorkFiles", fileId.ToString());
                        using (FileStream output = new FileStream(path, FileMode.Create))
                        {
                            file.CopyTo(output);
                        }
                    }
                }

                // Dessa lägger vi i Databas-metoden Update-Task
                // ...
                // updateModel.Task.ModifiedDate = DateTime.Now;
                // updateModel.Task.ModifiedBy = Info.CurrentUser; // User.Identity.Name;

                if (DataService.AddTaskHistory(updateModel.Task))
                {
                    DataService.UpdateTask(updateModel.Task, Info.CurrentUser);
                }
            }
            else
            {
                return RedirectToAction("TaskUpdateNotValid");
            }

            return RedirectToAction("Edit", "Operation", new { id = updateModel.Task.OperationId });
        }

        public IActionResult Delete(int id)
        {
            Task task = DataService.GetTaskById(id);

            DataService.DeleteTask(task);

            // Om aktiviteten tas bort, ska även bifogade filer för den tas bort?
            // ...

            return RedirectToAction("Edit", "Operation", new { id = task.OperationId });
        }


        //public IActionResult DeleteFile(int Id, string fileName)
        //{
        //    Task task = DataService.GetTaskById(Id);

        //    //File currentFile = DataService.GetFile()

        //    string path = Path.Combine(hostingEnvironment.ContentRootPath, "WorkFiles", Id.ToString());

        //    string filePath = Path.Combine(path, Path.GetFileName(fileName));

        //    if (System.IO.File.Exists(filePath))
        //    {
        //        // GC.Collect();
        //        // GC.WaitForPendingFinalizers(); // These lines were used to solve conflict from open Filestream when trying to delete file.
        //                                          // Instead, we used a using { } to enclose Filestream object when uploading a file.
        //                                          // Solved, no conflict.

        //        System.IO.File.Delete(filePath);
        //    }

        //    return RedirectToAction("Edit", "Task", new { id = Id });
        //    // new { id = task });
        //}

        public IActionResult History(int taskId)
        {
            List<TasksHistory> tasks = DataService.GetTasksHistory(taskId);

            Task task = DataService.GetTaskById(taskId);

            // Lägg till nuvarande version (ej sparad i TasksHistory)
            // så att även den senaste uppdateringen syns i historiken

            TasksHistory current = new TasksHistory();
            current.HasResult = task.HasResult;
            current.Instruction = task.Instruction;
            current.ModifiedBy = task.ModifiedBy;
            current.ModifiedDate = task.ModifiedDate;
            current.Name = task.Name;
            current.OperationId = task.OperationId;
            current.SignatureType = task.SignatureType;
            current.TaskId = task.Id;
            current.TaskOrder = task.TaskOrder;
            tasks.Add(current);

            tasks = tasks.OrderByDescending(t => t.ModifiedDate).ToList();

            ViewData["TaskName"] = task.Name;
            ViewData["OperationName"] = DataService.GetOperationById(task.OperationId).Name;

            return View(tasks);
        }
    }
}