﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mime;
using System.Threading.Tasks;
using ExampleWebApp.Database;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;
using MimeTypes;
using File = ExampleWebApp.Database.File;

namespace ExampleWebApp.Controllers
{
    public class FilesController : Controller
    {
        private IWebHostEnvironment Env;
        private MaintenanceDataService DataService;

        public FilesController(IWebHostEnvironment env, MaintenanceDataService dataservice)
        {
            Env = env;
            DataService = dataservice;
        }

        public IActionResult Open(int id)
        {
            // string fileName = "Lauterbrunnen.jpg";
            File file = DataService.GetFile(id);
            string ext = Path.GetExtension(file.Name);

            string path = Path.Combine(Env.ContentRootPath, "WorkFiles", id.ToString());
            FileStream source = System.IO.File.OpenRead(path);
            ContentDispositionHeaderValue header = new ContentDispositionHeaderValue("attachment");

            header.FileName = file.Name; // hämta från databas
            header.DispositionType = DispositionTypeNames.Inline;
            Response.Headers[HeaderNames.ContentDisposition] = header.ToString();
            return File(source, MimeTypeMap.GetMimeType(ext));
        }

        public IActionResult Delete(int fileId, int taskId)
        {
            File file = DataService.GetFile(fileId);
            DataService.DeleteFile(file);

            return RedirectToAction("Edit", "Task", new { id = taskId });
        }
    }
}
