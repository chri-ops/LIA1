﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ExampleWebApp.Database;
using Microsoft.AspNetCore.Mvc;

namespace ExampleWebApp.Controllers
{
    public class MachineController : Controller
    {
        private MaintenanceDataService DataService;

        public MachineController(MaintenanceDataService service)
        {
            DataService = service;
        }

        public IActionResult Index()
        {
            ViewData["Alla Maskiner"] = DataService.GetAllMachines();
            return View();
        }

        public IActionResult Add()
        {
            Machine model = new Machine();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(Machine machine)
        {
            DataService.AddMachine(machine);
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            Machine machine = DataService.GetMachineById(id);

            return View(machine);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Machine machineUpdate)
        {
            if (ModelState.IsValid)
            {
                DataService.UpdateMachine(machineUpdate);
            }

            else
            {
                return RedirectToAction("MachineUpdateNotValid");
            }
                                          
            return RedirectToAction("Index");
        }

        public IActionResult MachineUpdateNotValid()
        {
            return View();
        }

        public IActionResult Delete(int id)
        {
            Machine machine = DataService.GetMachineById(id);

            DataService.DeleteOperationMachineByMachine(machine);

            DataService.DeleteMachine(machine);

            return RedirectToAction("Index");
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //[ActionName("Delete")]
        //public IActionResult ConfirmDelete(Machine machine)
        //{
        //    DataService.DeleteMachine(machine);

        //    return RedirectToAction("Index");
        //}
    }
}