﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ExampleWebApp.Database;
using ExampleWebApp.Models;
using ExampleWebApp.Services;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Task = ExampleWebApp.Database.Task;

namespace ExampleWebApp.Controllers
{
    public class OperationController : Controller
    {
        MaintenanceDataService DataService;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly InformationService Info;

        public OperationController(MaintenanceDataService service, IWebHostEnvironment environment, InformationService info)
        {
            DataService = service;
            hostingEnvironment = environment;
            Info = info;
        }

        public IActionResult Index(int id)
        {
            ViewData["Alla operatörsunderhåll"] = DataService.GetAllOperations();

            List<Operation> listOfOperations = new List<Operation>();

            if (id > 0)
            {
                listOfOperations = DataService.GetOperationsByMachineId(id);
                ViewData["SelectedMachine"] = id;
            }

            else
            {
                listOfOperations = DataService.GetAllOperations();
                ViewData["SelectedMachine"] = 0;
            }

            // Adding this because
            // we need to be able to use Html.DisplayFor in our View to get the Display formats for ScheduleType,
            // so that our View shows 'År, Månad, etc' instead of 'Year, Month..' - we need a model for that.

            ViewData["MachineList"] = DataService.GetAllMachines();

            return View(listOfOperations);
        }

        public IActionResult Add()
        {
            // To send pre-set values into our form..

            OperationViewModel model = new OperationViewModel();

            model.operation = new Operation();
            model.operation.Active = true;
            var d = DateTime.Now;
            model.DatePart = new DateTime(d.Year, d.Month, d.Day, d.Hour, d.Minute, 0);
            model.TimePart = new DateTime(d.Year, d.Month, d.Day, d.Hour, d.Minute, 0);
            // ^ We want our Date-field to display the current actual time, as default when creating an operation.

            model.operation.Interval = 1;

            return View(model);                // ...
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Add(OperationViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Integration of DatePart and Timepart of View inputs:
                model.operation.Start = model.DatePart.Date; //  This only sets the timepart to 00:00:00 of the Start property.
                model.operation.Start = model.operation.Start.Add(model.TimePart.TimeOfDay); // This adds the timepart into the datetime object.
                // Datetime integration should now be done.

                model.operation.CreatedDate = DateTime.Now;
                model.operation.CreatedBy = Info.CurrentUser;

                DataService.AddOperation(model.operation);
            }

            else
            {
                return RedirectToAction("OperationUpdateNotValid");
            }

            return RedirectToAction("Edit", "Operation", new { id = model.operation.Id });
        }

        public IActionResult Edit(int id)
        {
            OperationViewModel model = new OperationViewModel();

            model.operation = DataService.GetOperationById(id);

            // Below getting date and time to show in View:
            model.DatePart = model.operation.Start.Date; // Getting only date and setting time to 00:00:00.
            model.TimePart = model.operation.Start; // Getting the whole datetime but doesn't matter: only timepart will be shown in view anyway.
            // Now the actual date and time will be shown in the edit view.

            List<Task> taskList = DataService.GetTasks(id);
            ViewData["taskList"] = taskList;

            List<Machine> machineList = DataService.GetAllMachines();
            ViewData["machineList"] = machineList;

            model.CheckedMachinesId = DataService.GetMachinesIdByOperationId(id);

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(OperationViewModel updateModel, List<int> machineIdList) // List of Machine Id's: the chosen machines from user-checked boxes for this operation!
        {
            if (ModelState.IsValid)
            {
                updateModel.operation.Id = updateModel.Id; // Retrieving the id for the operation - which in this case is stored in the view model object.
                                                           // Without this line, the operation.Id till be zero, and the UpdateOperation method below will create a new database object with a new Id,
                                                           // which we do not want.

                // Integration of DatePart and Timepart of View inputs:
                updateModel.operation.Start = updateModel.DatePart.Date; //  This only sets the timepart to 00:00:00 of the Start property.
                updateModel.operation.Start = updateModel.operation.Start.Add(updateModel.TimePart.TimeOfDay); // This adds the timepart into the datetime object.
                                                                                                               // Datetime integration should now be done.

                // Logic for updating checked machines for this operation:
                DataService.UpdateOperationMachines(updateModel.operation.Id, machineIdList);

                if (DataService.AddOperationHistory(updateModel.operation))
                {
                    DataService.UpdateOperation(updateModel.operation, Info.CurrentUser);
                }
            }
            else
            {
                return RedirectToAction("OperationUpdateNotValid");
            }

            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            Operation operation = DataService.GetOperationById(id);

            List<Task> tasksOfOperation = DataService.GetTasks(id);
            foreach (Task task in tasksOfOperation)
            {
                DeleteFilesAndFolders(task); // Deletes all added files and folders for the task to be deleted.
                DataService.DeleteTask(task); // Deletes all tasks from Task table for this operation.
            }

            DataService.DeleteOperationMachineByOperation(operation); // Deletes all entries in connection table OperationMachines containing this operation.
            DataService.DeleteOperation(operation); // Deletes the operation from Operations table.

            return RedirectToAction("Index");
        }

        public void DeleteFilesAndFolders(Task task)
        {
            string path = Path.Combine(hostingEnvironment.ContentRootPath, "WorkFiles", task.Id.ToString());

            System.IO.DirectoryInfo directory = new DirectoryInfo(path);

            if (directory.Exists)
            {
                directory.Delete(true);
            }
        }

        public IActionResult History(int operationId)
        {
            List<OperationsHistory> operations = DataService.GetOperationsHistory(operationId);

            // Lägg till nuvarande version (ej sparad i OperationsHistory)
            // så att nuvarande också visas under historik
            Operation operation = DataService.GetOperationById(operationId);
            OperationsHistory current = new OperationsHistory();
            current.Active = operation.Active;
            current.Interval = operation.Interval;
            current.ModifiedBy = operation.ModifiedBy;
            current.ModifiedDate = operation.ModifiedDate;
            current.Name = operation.Name;
            current.OperationId = operation.Id;
            current.ScheduleType = operation.ScheduleType;
            current.Start = operation.Start;
            operations.Add(current);

            operations = operations.OrderByDescending(o => o.ModifiedDate).ToList();

            ViewData["OperationName"] = DataService.GetOperationById(operationId).Name;

            return View(operations);
        }

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public IActionResult Delete(Operation operation)
        //{
        //    DataService.DeleteOperation(operation);

        //    return RedirectToAction("Index");
        //}
    }
}