﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using ExampleWebApp.Database;
using Action = ExampleWebApp.Database.Action;

namespace ExampleWebApp.Models
{
    public class HomeViewModel
    {
        public List<Action> OngoingActions { get; set; }
        public List<HomeViewItem> ScheduledActions { get; set; }
        public HomeViewModel()
        {
            ScheduledActions = new List<HomeViewItem>();
            OngoingActions = new List<Action>();
        }
    }

    public class HomeViewItem
    {
        public OperationMachine OperationMachine { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = false)]
        public DateTime OperationStart { get; set; }
        public ScheduleTypes OperationScheduleType { get; set; }
        public int OperationInterval { get; set; }

        public bool OperationActive { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = false)]
        public DateTime Scheduled { get; set; }

        public HomeViewItem()
        {
            OperationMachine = new OperationMachine();
        }
    }
}
