﻿using ExampleWebApp.Database;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Task = ExampleWebApp.Database.Task;

namespace ExampleWebApp.Models
{
    public class TaskViewModel
    {
        public int Id { get; set; }
        public Task Task { get; set; }

        public List<int> CheckedMachinesId;

        public List<IFormFile> Files { get; set; }

        public List<TaskFile> TaskFiles { get; set; }

        public TaskViewModel()
        {
            Files = new List<IFormFile>();
        }
    }
}
