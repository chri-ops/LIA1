﻿using ExampleWebApp.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Action = ExampleWebApp.Database.Action; // !!
using Task = ExampleWebApp.Database.Task; // !!

namespace ExampleWebApp.Models
{
    public class ActionExecuteViewModel
    {
        // Properties
        public bool ActionExists { get; set; }
        public Action Action { get; set; } // using Database.Action
        public int? MachineId { get; set; }
        public int OperationId { get; set; }
        public List<Task> Tasks { get; set; } // using Database.Task
        public List<bool> HasResultList { get; set; }
        public List<string> ResultList { get; set; }
        //public List<List<TaskFile>> ListOfTaskFileLists { get; set; }

        public List<ActionTask> ActionTasks { get; set; }

        // Constructor
        public ActionExecuteViewModel()
        {
            // Make new empty lists and Action Object..
            Tasks = new List<Task>();
            HasResultList = new List<bool>();
            ResultList = new List<string>();
            //ListOfTaskFileLists = new List<List<TaskFile>>();
            ActionTasks = new List<ActionTask>();
            Action = new Action();
        }
    }
}
