﻿using ExampleWebApp.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Models
{
    public class ActionEditViewModel
    {
        public long Id { get; set; }
        public int OperationId { get; set; }
        public int? MachineId { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = false)]
        public DateTime Started { get; set; }
        public DateTime? Completed { get; set; }
        [StringLength(100)]
        public string StartedBy { get; set; }
        [StringLength(100)]

        [Required(ErrorMessage = "Vem som avslutat utförandet måste vara ifyllt.")]
        public string CompletedBy { get; set; }
        public string Comment { get; set; }



        // Operation-view-props
        public string OperationName { get; set; }
        public bool OperationActive { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = false)]
        public DateTime OperationStart { get; set; }
        public ScheduleTypes OperationScheduleType { get; set; }
        public int OperationInterval { get; set; }



        // Task-view-props
        public List<Database.Task> Tasks { get; set; }
        public List<bool> HasResultList { get; set; }

        public List<string> ResultList { get; set; }

        public ActionEditViewModel()
        {
            Tasks = new List<Database.Task>();
            HasResultList = new List<bool>();
            ResultList = new List<string>();
        }
    }
}
