﻿using ExampleWebApp.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Models
{
    public class ActionAddViewModel
    {
        public int OperationId { get; set; }
        public int MachineId { get; set; }

        [Required(ErrorMessage = "Fyll i vem som påbörjat utförandet.")]
        public string StartedBy { get; set; }
        public string Comment { get; set; }

        // Operation-view-props
        public string OperationName { get; set; }
        public bool OperationActive { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = false)]
        public DateTime OperationStart { get; set; }
        public ScheduleTypes OperationScheduleType { get; set; }
        public int OperationInterval { get; set; }

        // Task-view-props
        public List<Database.Task> Tasks { get; set; }

        public ActionAddViewModel()
        {
            Tasks = new List<Database.Task>();
        }
    }
}
