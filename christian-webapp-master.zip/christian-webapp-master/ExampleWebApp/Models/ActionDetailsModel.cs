﻿using ExampleWebApp.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Task = ExampleWebApp.Database.Task;

namespace ExampleWebApp.Models
{
    public class ActionDetailsModel
    {
        public long Id { get; set; }
        public int OperationId { get; set; }
        public int? MachineId { get; set; }
        public string Name { get; set; }
        public string MachineName { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = false)]
        public DateTime Started { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = false)]
        public DateTime? Completed { get; set; }

        [StringLength(100)]
        public string StartedBy { get; set; }

        [StringLength(100)]
        public string CompletedBy { get; set; }
        public string Comment { get; set; }

        public List<Task> Tasks { get; set; }

        //

        public List<ActionTask> ActionTasks { get; set; }

        public ActionDetailsModel()
        {
            ActionTasks = new List<ActionTask>();
            Tasks = new List<Task>();
        }
    }
}
