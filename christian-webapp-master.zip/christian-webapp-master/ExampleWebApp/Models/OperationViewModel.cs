﻿using ExampleWebApp.Database;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Models
{
    public class OperationViewModel
    {
        public int Id { get; set; }
        public Operation operation { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "Datum måste vara ifyllt.")]
        public DateTime DatePart { get; set; }

        [DisplayFormat(DataFormatString = "{0:t}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "Tid måste vara ifyllt.")]
        public DateTime TimePart { get; set; }

        public List<int?> CheckedMachinesId { get; set; }

        public OperationViewModel()
        {

        }
    }
}
