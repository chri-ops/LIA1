﻿using ExampleWebApp.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.Web.CodeGeneration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using File = ExampleWebApp.Database.File;

namespace ExampleWebApp.Database
{
    public class MaintenanceDataService
    {
        private MaintenanceDatabase Db;
        private readonly InformationService Info;

        public MaintenanceDataService(MaintenanceDatabase db, InformationService info)
        {
            Db = db;
            Info = info;
        }

        /// <summary>
        /// Adding a machine to the database.
        /// </summary>
        /// <param name="machine">The machine object to be added</param>
        public void AddMachine(Machine machine)
        {
            machine.Modified = DateTime.Now;
            Db.Machines.Add(machine);
            Db.SaveChanges();
        }

        public File GetFile(int id)
        {
            return Db.Files.Find(id);
        }


        /// <summary>
        /// Gets a machine corresponding to Id from the database.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>The corresponding machine</returns>
        public Machine GetMachineById(int? id)
        {
            return Db.Machines.Find(id);
        }

        public List<OperationMachine> GetAllOperationMachines()
        {
            return Db.OperationMachines.ToList();
        }




        /// <summary>
        /// Gets all machines in a name-ordered list from the db.
        /// </summary>
        /// <returns>List of all machines</returns>
        public List<Machine> GetAllMachines()
        {
            return Db.Machines.OrderBy(m => m.Name).ToList();
        }

        
        /// <summary>
        /// Updates a machine from user input.
        /// </summary>
        /// <param name="machineUpdate">The machine update object to be saved</param>
        public void UpdateMachine(Machine machineUpdate)
        {
            machineUpdate.Modified = DateTime.Now;
            Db.Machines.Update(machineUpdate);
            Db.SaveChanges();
        }


        /// <summary>
        /// Deletes a machine from the database.
        /// </summary>
        /// <param name="machine">The machine object to be deleted</param>
        public void DeleteMachine(Machine machine)
        {
            Db.Machines.Remove(machine);
            Db.SaveChanges();
        }


        // ↑ Machine methods
        // ↓ Operation methods


        public void AddOperation(Operation operation)
        {
            operation.CreatedBy = Info.CurrentUser;
            operation.CreatedDate = DateTime.Now;
            operation.ModifiedDate = operation.CreatedDate;
            Db.Operations.Add(operation);
            Db.SaveChanges();
        }

        public Operation GetOperationById(int id)
        {
            return Db.Operations.Find(id);
        }

        public List<Operation> GetAllOperations()
        {
            return Db.Operations.OrderBy(m => m.Start).ToList();
        }


        public void UpdateOperation(Operation operationUpdate, string userName)
        {
            operationUpdate.ModifiedDate = DateTime.Now;
            operationUpdate.ModifiedBy = userName;
            Db.Operations.Update(operationUpdate);
            Db.SaveChanges();
        }

        public List<TaskFile> GetTaskFiles(int taskId)
        {
            return Db.TaskFiles.Where(f => f.TaskId == taskId).ToList();
        }

        internal void DeleteOperation(Operation operation)
        {
            Db.Operations.Remove(operation);
            Db.SaveChanges();
        }

        public bool HasActions(Operation operation)
        {
            bool hasActions = false;
            if (Db.Actions.Any(o => o.OperationId == operation.Id))
            {
                hasActions = true;
            }
            return hasActions;
        }


        // ↑ Operation methods
        // ↓ Task methods


        public void AddTask(Task task)
        {
            task.CreatedBy = Info.CurrentUser;
            task.CreatedDate = DateTime.Now;
            task.ModifiedDate = task.CreatedDate;
            Db.Tasks.Add(task);
            Db.SaveChanges();
        }


        public Task GetTaskById(int id)
        {
            return Db.Tasks.Find(id);
        }


        public List<Task> GetTasks(int operationId)
        {
            var result = Db.Tasks.Where(t => t.OperationId == operationId).OrderBy(t => t.TaskOrder).ToList();

            return result;
        }

        public void UpdateTask(Task taskUpdate, string userName)
        {
            taskUpdate.ModifiedDate = DateTime.Now;
            taskUpdate.ModifiedBy = userName;
            Db.Tasks.Update(taskUpdate);
            Db.SaveChanges();
        }


        public void DeleteTask(Task task)
        {
            Db.Tasks.Remove(task);
            Db.SaveChanges();
        }


        // ↑ Task methods
        // ↓ MachineOperation methods


        public List<OperationMachine> GetOperationMachinesByOperationId(int operationId)
        {
            var result = Db.OperationMachines.Where(OM => OM.OperationId == operationId).ToList();

            return result;
        }


        public List<int?> GetMachinesIdByOperationId(int operationId)
        {
            List<OperationMachine> operationMachines = GetOperationMachinesByOperationId(operationId);

            List<int?> machineIdList = new List<int?>();

            for (int i = 0; i < operationMachines.Count; i++)
            {
                machineIdList.Add(operationMachines[i].MachineId);
            }

            return machineIdList;
        }

        public void UpdateOperationMachines(int currentOperationId, List<int> machineIds)
        {
            List<OperationMachine> operationMachines = GetOperationMachinesByOperationId(currentOperationId);

            // This line CLEARS all machines for this operation;
            // so that only the update will be stored (including checked-out machines)
            Db.OperationMachines.RemoveRange(operationMachines);

            // The following lines PUTS BACK chosen machines for the operation:
            for (int i = 0; i < machineIds.Count; i++)
            {
                OperationMachine operationMachine = new OperationMachine { OperationId = currentOperationId, MachineId = machineIds[i] };

                Db.OperationMachines.Add(operationMachine);
            }

            Db.SaveChanges();
        }

        public List<Operation> GetOperationsByMachineId(int id)
        {
            var operationMachines = Db.OperationMachines.Where(m => m.MachineId == id).ToList();
            List<Operation> operations = new List<Operation>();

            foreach (OperationMachine op in operationMachines)
            {
                Operation operation = GetOperationById(op.OperationId);

                operations.Add(operation);
            }

            return operations;
        }


        public List<Machine> GetOperationMachines(int operationId)
        {
            var operationMachines = Db.OperationMachines.Where(om => om.OperationId == operationId).Select(om => om.MachineId);
            return Db.Machines.Where(m => operationMachines.Contains(m.Id)).OrderBy(m => m.Name).ToList();
        }


        public void DeleteOperationMachineByMachine(Machine machine)
        {
            var operationMachines = Db.OperationMachines.Where(m => m.MachineId == machine.Id);
            Db.OperationMachines.RemoveRange(operationMachines);
            Db.SaveChanges();
        }

        public void DeleteOperationMachineByOperation(Operation operation)
        {
            var operationMachines = Db.OperationMachines.Where(m => m.OperationId == operation.Id);
            Db.OperationMachines.RemoveRange(operationMachines);
            Db.SaveChanges();
        }


        // ↑ MachineOperation methods
        // ↓ Action methods

        public void AddAction(Action action)
        {
            Db.Actions.Add(action);
            Db.SaveChanges();
        }


        public Action GetAction(long id)
        {
            return Db.Actions.Find(id);
        }

        public Action GetAction(int operationId, int? machineId)
        {
            return Db.Actions.Where(action => action.OperationId == operationId && action.MachineId == machineId).FirstOrDefault();
        }


        /// <summary>
        /// Gets all started, unfinished actions.
        /// </summary>
        /// <returns>List of started, unfinished actions</returns>
        public List<Action> GetOngoingActions()
        {
            var uncompletedActions = Db.Actions.Where(x => x.Completed == null).ToList();
            return uncompletedActions.ToList();
        }

        public Action GetLatestCompletedAction(int operationId, int? machineId)
        {
            return Db.Actions.Where(action => action.OperationId == operationId && action.MachineId == machineId && action.Completed != null)
                .OrderByDescending(action => action.Completed).Take(1).SingleOrDefault();
        }

        public void UpdateAction(Action action)
        {
            Db.Update(action);
            Db.SaveChanges();
        }

        public List<Action> GetActionsForOperation(int operationId)
        {
            return Db.Actions.Where(action => action.OperationId == operationId).ToList();
        }


        // ↑ Action methods
        // ↓ ActionTask methods

        public List<ActionTask> AddActionTasks(List<ActionTask> actionTasks)
        {
            foreach (ActionTask actionTask in actionTasks)
            {
                Db.ActionTasks.Add(actionTask);
            }
            
            Db.SaveChanges();

            return actionTasks;
        }

        public void UpdateActionTasks(List<ActionTask> actionTasksUpdate)
        {
            foreach (ActionTask actionTask in actionTasksUpdate)
            {
                Db.ActionTasks.Update(actionTask);
            }

            Db.SaveChanges();
        }

        public List<ActionTask> GetActionTasks(long actionId)
        {
            return Db.ActionTasks.Where(actionTask => actionTask.ActionId == actionId).OrderBy(a => a.TaskOrder).ToList();
        }


        // ↑ ActionTask methods
        // ↓ OperationHistory methods

        public bool AddOperationHistory(Operation changedOperation)
        {
            bool anyChange = false;
            Operation operationBeforeChange = GetOperationById(changedOperation.Id);
            if (operationBeforeChange.AnyChanges(changedOperation))
            {
                anyChange = true;
                OperationsHistory history = operationBeforeChange.CreateHistory();
                Db.OperationsHistory.Add(history);
                Db.SaveChanges();
            }
            Db.Entry(operationBeforeChange).State = EntityState.Detached;
            return anyChange;
        }


        public List<OperationsHistory> GetOperationsHistory(int operationId)
        {
            return Db.OperationsHistory.Where(x => x.OperationId == operationId).ToList();
        }



        // ↑ OperationHistory methods
        // ↓ TasksHistory methods

        public bool AddTaskHistory(Task changedTask)
        {
            bool anyChange = false;
            Task taskBeforeChange = GetTaskById(changedTask.Id);
            if (taskBeforeChange.AnyChanges(changedTask))
            {
                anyChange = true;
                TasksHistory history = taskBeforeChange.CreateHistory();
                Db.TasksHistory.Add(history);
                Db.SaveChanges();
            }
            Db.Entry(taskBeforeChange).State = EntityState.Detached;
            return anyChange;
        }

        public List<TasksHistory> GetTasksHistory(int taskId)
        {
            return Db.TasksHistory.Where(x => x.TaskId == taskId).ToList();
        }


        // ↑ TasksHistory methods
        // ↓ File methods


        /// <summary>
        /// Adds a File entry to the database
        /// </summary>
        /// <param name="newFile">File object to be inserted</param>
        /// <returns>Id of inserted File (newly assigned by the database)</returns>
        public int AddFile(File newFile)
        {
            newFile.IsDeleted = false;

            Db.Files.Add(newFile);
            Db.SaveChanges();

            return newFile.Id;
        }

        public void DeleteFile(File file)
        {
            file.IsDeleted = true;
            Db.Files.Update(file);
            Db.SaveChanges();
        }


        // ↑ File methods
        // ↓ TaskFile methods

        public void AddTaskFile(TaskFile taskFile)
        {
            Db.TaskFiles.Add(taskFile);
            Db.SaveChanges();
        }



        // ↑ TaskFile methods
        // ↓ ActionTaskFile methods

        public void AddActionTaskFiles(List<ActionTaskFile> actionTaskFiles)
        {
            foreach (ActionTaskFile actionTaskFile in actionTaskFiles)
            {
                Db.ActionTaskFiles.Add(actionTaskFile);
            }

            Db.SaveChanges();
        }


        public List<ActionTaskFile> GetActionTaskFiles(long actionTaskId)
        {
            return Db.ActionTaskFiles.Where(atF => atF.ActionTaskId == actionTaskId).ToList();
        }
    }
}