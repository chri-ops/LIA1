﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Database
{
    public class OperationsHistory
    {
        public int Id { get; set; }
        public int OperationId { get; set; }

        [StringLength(100)]
        public string Name { get; set; }
        public bool Active { get; set; }
        public DateTime Start { get; set; }
        public ScheduleTypes ScheduleType { get; set; }
        public int Interval { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
    }
}
