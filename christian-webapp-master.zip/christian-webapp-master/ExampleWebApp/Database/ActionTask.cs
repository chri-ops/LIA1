﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Database
{
    public class ActionTask
    {
        public long Id { get; set; }
        public long ActionId { get; set; }
        public int TaskId { get; set; }
        public int TaskOrder { get; set; }
        [StringLength(100)]
        public string Name { get; set; }
        public string Instruction { get; set; }
        public bool HasResult { get; set; }
        public string Result { get; set; }


        public string[] GetFileNames(string webRootPath)
        {
            // Get files (whole filepaths) for this Operation
            string path = Path.Combine(webRootPath, "WorkFiles", this.TaskId.ToString());
            string[] fileNames = new string[0];
            if (Directory.Exists(path))
            {
                fileNames = Directory.GetFileSystemEntries(@path);
                for (int i = 0; i < fileNames.Length; i++)
                {
                    fileNames[i] = Path.GetFileName(fileNames[i]); // Corrects by removing path from file; leaving only filename.
                }
            }
            return fileNames;
        }
    }
}
