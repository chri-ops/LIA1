﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Database
{
    public class OperationMachine
    {
        public int OperationId { get; set; }
        public int? MachineId { get; set; }
    }
}
