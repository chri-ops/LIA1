﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Database
{
    public class MaintenanceDatabase : DbContext
    {
        public DbSet<Machine> Machines { get; set; }

        public DbSet<Operation> Operations { get; set; }

        public DbSet<Task> Tasks { get; set; }

        public DbSet<OperationMachine> OperationMachines { get; set; }

        public DbSet<Action> Actions { get; set; }

        public DbSet<ActionTask> ActionTasks { get; set; }

        public DbSet<OperationsHistory> OperationsHistory { get; set; }

        public DbSet<TasksHistory> TasksHistory { get; set; }

        public DbSet<File> Files { get; set; }

        public DbSet<TaskFile> TaskFiles { get; set; }

        public DbSet<ActionTaskFile> ActionTaskFiles { get; set; }

        public MaintenanceDatabase(DbContextOptions options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<OperationMachine>().HasKey("OperationId", "MachineId");
            modelBuilder.Entity<TaskFile>().HasKey("TaskId", "FileId");
            modelBuilder.Entity<ActionTaskFile>().HasKey("ActionTaskId", "FileId");
        }
    }
}
