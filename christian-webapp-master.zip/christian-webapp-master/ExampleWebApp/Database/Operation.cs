﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Database
{
    public enum ScheduleTypes
    {
        [Display(Name = "År")]
        Year = 0,

        [Display(Name = "Månad")]
        Month = 1,

        [Display(Name = "Vecka")]
        Week = 2,

        [Display(Name = "Dag")]
        Day = 3
    };

    public class Operation
    {
        public int Id { get; set; }

        [StringLength(100)]
        [Required(ErrorMessage = "Namn på operationsunderhåll måste vara ifyllt.")]
        public string Name { get; set; }

        [DefaultValue(true)]
        public bool Active { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd HH:mm}", ApplyFormatInEditMode = false)]
        [Required(ErrorMessage = "Datum och tid måste vara ifyllt.")]
        public DateTime Start { get; set; }

        public ScheduleTypes ScheduleType { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Intervall måste vara 1 eller högre.")]
        public int Interval { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime ModifiedDate {get; set;}

        public string ModifiedBy { get; set; }

        public Operation()
        {
            Active = true;
        }

        public DateTime Next(Database.Action latestCompleted)
        {
            if (latestCompleted != null && latestCompleted.Completed.HasValue)
            {
                TimeSpan interval;
                switch (ScheduleType)
                {
                    case ScheduleTypes.Year:
                        interval = new TimeSpan(365, 0, 0, 0);
                        break;
                    case ScheduleTypes.Month:
                        interval = new TimeSpan(30, 0, 0, 0);
                        break;
                    case ScheduleTypes.Week:
                        interval = new TimeSpan(7, 0, 0, 0);
                        break;
                    case ScheduleTypes.Day:
                        interval = new TimeSpan(1, 0, 0, 0);
                        break;
                    default:
                        interval = new TimeSpan(1, 0, 0, 0);
                        break;
                }
                return latestCompleted.Completed.Value + interval;
            }
            else
            {
                return Start;
            }
        }

        public bool AnyChanges(Operation other)
        {
            bool anyChanges = !(Active == other.Active
                && Interval == other.Interval
                && Name == other.Name
                && ScheduleType == other.ScheduleType
                && Start == other.Start);
            return anyChanges;
        }

        public OperationsHistory CreateHistory()
        {
            OperationsHistory oh = new OperationsHistory();
            oh.OperationId = Id;
            oh.Active = Active;
            oh.Interval = Interval;
            oh.ModifiedBy = ModifiedBy;
            oh.ModifiedDate = ModifiedDate;
            oh.Name = Name;
            oh.ScheduleType = ScheduleType;
            oh.Start = Start;
            return oh;
        }
    }
}
