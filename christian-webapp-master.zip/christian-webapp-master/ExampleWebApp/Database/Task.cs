﻿using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Database
{
    public enum SignatureTypes
    {
        [Display(Name = "Ingen")]
        None,

        [Display(Name = "Valfri")]
        Input,

        [Display(Name = "Aktuell användare")]
        CurrentUser
    }

    public class Task
    {
        public int Id { get; set; }
        public int OperationId { get; set; }
        public int TaskOrder { get; set; }

        [StringLength(100)]
        [Required(ErrorMessage="Uppgiftsnamn måste vara ifyllt.")]
        public string Name { get; set; }
        public string Instruction { get; set; }
        public bool HasResult { get; set; }
        public SignatureTypes SignatureType { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }

        public Task()
        {
            
        }

        public string[] GetFileNames(string webRootPath)
        {
            // Get files (whole filepaths) for this Operation
            string path = Path.Combine(webRootPath, "WorkFiles", this.Id.ToString());
            string[] fileNames = new string[0];
            if (Directory.Exists(path))
            {
                fileNames = Directory.GetFileSystemEntries(@path);
                for (int i = 0; i < fileNames.Length; i++)
                {
                    fileNames[i] = Path.GetFileName(fileNames[i]); // Corrects by removing path from file; leaving only filename.
                }
            }
            return fileNames;
        }

        public bool AnyChanges(Task other)
        {
            bool anyChanges = !(Name == other.Name
                && Instruction == other.Instruction
                && HasResult == other.HasResult
                && SignatureType == other.SignatureType
                && TaskOrder == other.TaskOrder);
            return anyChanges;
        }

        public TasksHistory CreateHistory()
        {
            TasksHistory th = new TasksHistory();
            th.TaskId = Id;
            th.OperationId = OperationId;
            th.Name = Name;
            th.Instruction = Instruction;
            th.HasResult = HasResult;
            th.SignatureType = SignatureType;
            th.TaskOrder = TaskOrder;
            th.ModifiedBy = ModifiedBy;
            th.ModifiedDate = ModifiedDate;

            return th;
        }
    }
}