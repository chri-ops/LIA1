﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Database
{
    public class TasksHistory
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public int OperationId { get; set; }
        public int TaskOrder { get; set; }

        [StringLength(100)]
        public string Name { get; set; }
        public string Instruction { get; set; }
        public bool HasResult { get; set; }
        public SignatureTypes SignatureType { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
    }
}
