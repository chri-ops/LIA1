﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ExampleWebApp.Migrations
{
    public partial class RemoveTaskFileName : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FileName",
                table: "Tasks");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "FileName",
                table: "Tasks",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
