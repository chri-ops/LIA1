﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ExampleWebApp.Migrations
{
    public partial class ShortenedPropnamesNameMachineNameActionclass : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MachineNameAtStart",
                table: "Actions");

            migrationBuilder.DropColumn(
                name: "OperationNameAtStart",
                table: "Actions");

            migrationBuilder.AddColumn<string>(
                name: "MachineName",
                table: "Actions",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "Actions",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MachineName",
                table: "Actions");

            migrationBuilder.DropColumn(
                name: "Name",
                table: "Actions");

            migrationBuilder.AddColumn<string>(
                name: "MachineNameAtStart",
                table: "Actions",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "OperationNameAtStart",
                table: "Actions",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
