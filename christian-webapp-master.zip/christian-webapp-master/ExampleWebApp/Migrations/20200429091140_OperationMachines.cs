﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ExampleWebApp.Migrations
{
    public partial class OperationMachines : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OperationMachines",
                columns: table => new
                {
                    OperationId = table.Column<int>(nullable: false),
                    MachineId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OperationMachines", x => new { x.OperationId, x.MachineId });
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OperationMachines");
        }
    }
}
