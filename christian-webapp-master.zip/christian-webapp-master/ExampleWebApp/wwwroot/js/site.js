﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$(".invid-datepicker input").datepicker({
    language: "sv",
    calendarWeeks: true,
    autoclose: true
});
$(".invid-datepicker span").on("click", function () {
    $(this).closest(".invid-datepicker").find("input").datepicker("show");
});

$('.invid-summernote textarea').summernote();

//var saveBtn = document.getElementById("save-button");
//if (saveBtn) {
//    saveBtn.addEventListener("click", function () {
//        var spinner = document.getElementById("spinner-border");
//        if ($("form").valid() == true) {
//            spinner.style.visibility = "visible";
//        }
//    });
//}

$("#save-button").on("click", function () {
    if ($("form").valid() == true) {
        $("#spinner-border").css({ visibility: "visible" });
    }
});

$("#action-start-button").click(function () {
    console.log("action-start-button clicked - function running!");
    $(".completed-by").removeAttr('data-val');
    $(".completed-by").removeAttr('data-val-required');
    $("form").submit();
});

function deleteFileAfterConfirm(fileId, taskId) {
    console.log("Kör javascript");
    $("#invid-modal").modal();
    $("#delete-attachment-btn").off("click");
    $("#delete-attachment-btn").on("click", function () {
        window.location = "/Files/Delete/?fileId=" + fileId + "&taskId=" + taskId;
    });
}

function deleteTaskAfterConfirm(taskId) {
    $("#invid-modal").modal();
    $("#delete-attachment-btn").off("click");
    $("#delete-attachment-btn").on("click", function () {
        window.location = "/Task/Delete/" + taskId;
    });
}

function deleteMachineAfterConfirm(machineId) {
    $("#invid-modal").modal();
    $("#delete-attachment-btn").off("click");
    $("#delete-attachment-btn").on("click", function () {
        window.location = "/Machine/Delete/" + machineId;
    });
}

function deleteOperationAfterConfirm(operationId) {
    $("#invid-modal").modal();
    $("#delete-attachment-btn").off("click");
    $("#delete-attachment-btn").on("click", function () {
        window.location = "/Operation/Delete/" + operationId;
    });
}