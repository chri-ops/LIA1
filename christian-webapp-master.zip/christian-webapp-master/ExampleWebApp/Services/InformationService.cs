﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExampleWebApp.Services
{
    public class InformationService
    {
        private readonly IHttpContextAccessor Context;

        public InformationService(IHttpContextAccessor context)
        {
            Context = context;
        }

        public string CurrentUser
        {
            get
            {
                // return Context.HttpContext.User.Identity.Name;
                return "Developer";
            }
        }
    }
}
